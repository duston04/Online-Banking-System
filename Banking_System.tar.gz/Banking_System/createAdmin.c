#include<unistd.h>
#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<string.h>

void main(){

  struct{
    char id[100];
    char password[100];
    char fname[100];
    char lname[100];
  }admin;
  
  strcpy(admin.id, "darshan04");
  strcpy(admin.password, "darshan04");
  strcpy(admin.fname, "darshan");
  strcpy(admin.lname, "katkar");
  
  int fd = open(admin.id, O_RDWR | O_EXCL | O_CREAT, S_IRWXU);
  write(fd, &admin, sizeof(admin));
  close(fd);
  
  return;
  
}
