#include <sys/types.h>  // Import for `socket`, `connect`
#include <sys/socket.h> // Import for `socket`, `connect`
#include <netinet/ip.h> // Import for `struct sockaddr_in`, `htons`
#include <stdio.h>      
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

typedef struct customer{   //User structure
    char id[100];
    char lname1[100];
    char lname2[100];
    char fname1[100];
    char fname2[100];
    char password[100];
    char loginType[10];
    int amount;
}customer;

typedef struct admin{    //Admin structure
    char id[100];
    char password[100];
    char fname[100];
    char lname[100];
}admin;

void menu(int sd, char id[100]){

  int n,d;
  customer user;
  int lockCheck;
    
  while(1){    
    
    printf("Press the sr. no to use that facility...\n");
    printf("1. Deposit\n2. Withdraw\n3. Password Change\n4. Balance Enquiry\n5. View details\n");
    printf("Press any other no. to exit/return\n\n");

    scanf("%d", &n);
    
    write(sd, &n, sizeof(n));   //Send the choice to the client
    
    switch(n){
    
      case 1 :  //deposite
         read(sd, &user, sizeof(user));      //Take structure from the server
         if(strcmp(user.loginType, "Joint") == 0){  //if user is Joint then check for locking
           read(sd, &lockCheck, sizeof(lockCheck));   //Take lockcheck from the server.... to check if lock exists or not
           if(lockCheck == 1){  //locked
             printf("Transaction happening by other user please wait..\n");
             break;
           }
           else{ //no lock
             printf("Enter the amount you want to deposit : ");
  	    scanf("%d", &d);
  	    user.amount =  user.amount + d;  //performing operation
  	    printf("The new balance is : %d", user.amount);
  	    write(sd, &user, sizeof(user));   //Send the updated structure to server
             break;
           }
         }
         else{  //Noraml user 
           printf("Enter the amount you want to deposit : ");
  	  scanf("%d", &d);
  	  user.amount =  user.amount + d;    //performing operation
  	  printf("The new balance is : %d", user.amount);
  	  write(sd, &user, sizeof(user));     //Send the updated structure to server
           break;
         }
        
      case 2 :
         read(sd, &user, sizeof(user));             //Take structure from the server
         if(strcmp(user.loginType, "Joint") == 0){  //if user is Joint then check for locking
           read(sd, &lockCheck, sizeof(lockCheck));   //Take lockcheck from the server.... to check if lock exists or not
           if(lockCheck == 1){  //locked
             printf("Transaction happening by other user please wait..\n");
             break;
           }
           else{  //no lock
             printf("Enter the amount you want to withdraw : ");
  	    scanf("%d", &d);
  	    user.amount =  user.amount + d;     //performing operation
  	    printf("The new balance is : %d", user.amount);
  	    write(sd, &user, sizeof(user));      //Send the updated structure to server
             break;
           }
         }
         else{ //Noraml user 
           printf("Enter the amount you want to withdraw : ");
  	  scanf("%d", &d);
  	  user.amount =  user.amount + d;       //performing operation
  	  printf("The new balance is : %d", user.amount);
  	  write(sd, &user, sizeof(user));      //Send the updated structure to server
           break;
         }
        
      case 3 :  //Password change.. no locking ... same for both joint and normal user
         read(sd, &user, sizeof(user));    //Take structure from the server
         int passCheck;
  	char newPassword[100];
  	char oldPassword[100];
  	printf("Enter the old Password : ");
  	scanf(" %[^\n]%*c", oldPassword);
  	if(strcmp(oldPassword, user.password)){   //comparing oldpassword with the structure taken from server
  	                                          //not same
  	  passCheck = 1;
  	  write(sd, &passCheck, sizeof(passCheck));  //Send passCheck to server
    	  printf("Password Incorrect....\n");
         }
  	else{   //same password... hence take new password
  	  passCheck = 0;
  	  write(sd, &passCheck, sizeof(passCheck));
    	  printf("Enter the new Password : ");
    	  scanf(" %[^\n]%*c", newPassword);
    	  strcpy(user.password, newPassword);   //update the password in the structure
    	  write(sd, &user, sizeof(user));      //Send the updated structure to the server
     	  printf("Password is updated\n");
  	}
         break;
        
      case 4 :  // Balance enquiry
        read(sd, &user, sizeof(user));    //Take structure from the server
        if(strcmp(user.loginType, "Joint") == 0){  //if user is Joint then check for locking
           read(sd, &lockCheck, sizeof(lockCheck));  //Take lockcheck from the server.... to check if lock exists or not
           if(lockCheck == 1){ //locked
             printf("Transaction happening by other user please wait..\n");
             break;
           }
           else{ //no lock
             int t;
             //displaying the balance
             printf("Your balance is : %d \n\n", user.amount);
             printf("Press any no. to go back to menu\n");   
             scanf("%d", &t);            //to stay in the balace enquiry area
             write(sd, &t, sizeof(t));   //Send the t value to server
        	    break;
           }
         }
         else{ //Normal user  
           printf("Your balance is : %d", user.amount);
        	  break;
         }
        
      case 5 :
         read(sd, &user, sizeof(user));    //Take structure from the server
         if(strcmp(user.loginType, "Joint") == 0){  //if user is Joint then check for locking
           read(sd, &lockCheck, sizeof(lockCheck));  //Take lockcheck from the server.... to check if lock exists or not
           if(lockCheck == 1){  //locked
             printf("Transaction happening by other user please wait..\n");
             break;
           }
           else{ // no lock
             
             int t;
             //displaying the details
             printf("UserId is : %s \n", user.id);
  
  	    printf("The password is : %s \n", user.password);
 	
 	    printf("The primary user's Full Name is : %s %s \n", user.fname1, user.lname1);
    
  	    if(strcmp(user.loginType, "Joint") == 0){
    	      printf("The secondary user's Full Name is : %s %s \n", user.fname2, user.lname2);
  	    }
  	    
  	    printf("Press '0' to go back to menu\n");
             scanf("%d", &t);            //to stay in the balace enquiry area
             write(sd, &t, sizeof(t));   //Send the t value to server
  
             break;
           }
         }
         else{  
           printf("UserId is : %s \n", user.id);
  
  	  printf("The password is : %s \n", user.password);
 	
 	  printf("The primary user's Full Name is : %s %s \n", user.fname1, user.lname1);
    
  	  if(strcmp(user.loginType, "Normal")){
    	    printf("The secondary user's Full Name is : %s %s \n", user.fname2, user.lname2);
  	  }
  
           break;
         }
           
      default :
         printf("Returning to the previous menu....\n\n\n");
         return;
    }
    printf("\n\n\n");
  }
}

void create(int sd){

  int n;
  int check;
  customer user;
  char userID[100];
  
  printf("Enter the account type by pressing the sr. number...\n"); 
  printf("1. Normal Account\n2. Joint Account\n");
  scanf("%d",&n);
  
  write(sd, &n, sizeof(n));   //Sending the choice to the server
  
  if(n == 1)
    strcpy(user.loginType, "Normal");  //if 1 then normal
  else if(n == 2)
    strcpy(user.loginType, "Joint");   //if 2 then joint
  else{
    printf("Input invalid\n");      //If invalid go back
    return;
  }
  
  
  
  while(1){
    printf("Enter the id : ");
    scanf(" %[^\n]%*c", userID);
   
    write(sd, &userID, sizeof(userID));  //Sending the user ID to the server
    read(sd, &check, sizeof(check));     //Taking the check value from the server
    if(check == 0){  //if check=0 then user already exists
      printf("User id already exists...\n");
      continue;
    }
    else
      break;
  }
  
  strcpy(user.id, userID);   //copying the userID to the structure 
  
  
  //Now taking all the values from the user then storing them in the structure
  printf("Enter the first name : ");
  scanf(" %[^\n]%*c", user.fname1);
   
  printf("Enter the last name : ");
  scanf(" %[^\n]%*c", user.lname1);
 
  if(n == 2){
    printf("Enter the second user's first name : ");
    scanf(" %[^\n]%*c", user.fname2);
    printf("Enter the second user's last name : ");
    scanf(" %[^\n]%*c", user.lname2);
  }
  
  printf("Enter the password with minimum lenght 7 : ");
  scanf(" %[^\n]%*c", user.password);
  
  printf("Enter the amount you want to initially deposite : ");
  scanf("%d", &user.amount);
  
  write(sd, &user, sizeof(user)); //Sending the structure to the server
                                  //Server will store them in the file with name of userID
  
  printf("Account successfully created\n");
   
}

void userLogin(int sd){
  
  bool resultid, resultpass;

  char givenID[100];
  char givenPass[100];
  int n;
  int size;
  
  while(1){
  
    printf("\n\n\n=========================\n\n");
    
    printf("Press '0' to go to Main menu or any number to continue\n");
    scanf("%d",&n);
    
    write(sd, &n, sizeof(n));
    
    if(n == 0)    //Going back to the main menu
      break;
      
      
    printf("\n\nEnter the login id : ");
    scanf(" %[^\n]%*c", givenID);
    printf("%s \n", givenID); 
    size = sizeof(givenID);
    write(sd, &size, sizeof(size));   //Sending the size of ID to the server
    write(sd, &givenID, sizeof(givenID));   //Sending the ID to the server
    read(sd, &resultid, sizeof(resultid));   //Server will verify the ID and then will return the RESULT(bool) to the client...
    
    if(!resultid){    //IF result false then retype the ID
      printf("Incorrect id...\n"); 
      continue;
    }
      
    printf("Correct id...\n");  //If result true continue
    
    while(1){
      printf("\nPress '0' to return\n");
      printf("\nEnter the password : ");
      scanf(" %[^\n]%*c", givenPass);
      write(sd, &givenPass, sizeof(givenPass));   //Send the password to the server
      read(sd, &resultpass, sizeof(resultpass)); //Server will verify the Password and then will return the RESULT(bool) to the client...
    
      if(!resultpass){  //if result false retype the password
        if(strcmp(givenPass, "0") == 0){  //Type 0 to return
          break;
        }
        printf("Access Denied... Incorrect Password\n"); 
        continue;
      }
      else   //If result true then move forward
      {
        printf("Access Gained\n");
        int lockCheck;  //Variable to check if locked or not ... recieve it from the server
        customer user;
        read(sd, &user, sizeof(user));
    
        if(strcmp(user.loginType, "Normal") == 0){   //if userType is normal then
          read(sd, &lockCheck, sizeof(lockCheck));  //Recieve lockCheck from the client
          if(lockCheck == 1)       //if lockCheck is 1 then already locaked
          {
            printf("Client is already logged in from another terminal\n");
            lockCheck = 0;
            return;
          }
          else{ // Normal user entered  i.e no lock
               //Lock applied on the server side
            menu(sd, givenID);  // go to the banking menu
               //unlocked after returning to the server side
          } 
        }
        else{  //Joint user ...multiple logins possible
            menu(sd, givenID);
        }
        break;  //go to the main menu
      }
    }
  }
}

void userMenu(int sd){
  int c;
  while(1){
    printf("Select any one \n\n");
    printf("\n1. Login\n2. Create A New Account\n");
    printf("\n Press any other number to return to the main menu\n"); 
    scanf("%d", &c);
    write(sd, &c, sizeof(c));  //Writing the choice to the Server
    switch(c){
      case 1 :
        userLogin(sd); //Calling the userLogin function
        break;
      case 2 :
        create(sd); //Calling the create customer fn
        break;
      default:  //Going back to main menu
        printf("Invalid input...\n");
        return;
    }
  }
}

void nameChange(int sd, char str[100], int n){

  customer user;
  char name[100];
  
  read(sd, &user, sizeof(user));  //Taking the structure from the server(no use here)
  
  printf("Enter the first name : ");
  scanf(" %[^\n]%*c", name);
  
  write(sd, &name, sizeof(name));   //Sending the name to the server
  
  printf("Name update done\n");
  
  return;

}


void balanceChange(int sd, char str[100]){
  
  customer user;
  read(sd, &user, sizeof(user));    //Taking the structure from the server
  int newAmount;
  printf("Enter the updated amount : ");
  scanf("%d", &newAmount);
  user.amount = newAmount;      //Updating the user structure
  
  write(sd, &user, sizeof(user));  //Sending the updated structure to the server
  printf("Balance Changed\n"); 

  return;
}


void changeID(int sd, char str[100]){
  
  char newID[100];
  customer user;
  read(sd, &user, sizeof(user));    //Taking the structure from the server
  
  printf("Enter the new ID of the file : ");
  scanf(" %[^\n]%*c", newID);
  
  write(sd, &newID, sizeof(newID));  //Sending the newID to the server
  
  int l;
  read(sd, &l, sizeof(l));     //Taking l from the server
  if(l == 0)
    printf("New file created\n");
  else{
    printf("Unsuccessful\n");
    return;
  }
    
  int ul;                   //Taking ul from the server
  read(sd, &ul, sizeof(ul));
  if(ul == 0)
    printf("Old file deleted\n");
  else{
    printf("Unsuccessful delete\n");
    return; 
  }
    
  printf("ID changed successfully\n");
    
  return;

}


void modify(int sd){
  int n;
  int fd;
  char str[1000];
  customer user;
  
  while(1){
  
  while(1){
    printf("Enter the user id of the account you want to update \n");
    printf("Press '0' to return to the previous Menu\n");
    scanf(" %[^\n]%*c", str);
  
    write(sd, &str, sizeof(str));   //Sending the ID to the server
    if(strcmp(str, "0") == 0)
      return;
  
    read(sd, &fd, sizeof(fd));    //Taking the fd from the server
                                 //for verification
    if(fd == -1){
      printf("The file does not exist\n");
      continue;
    }
    else
      break;
  }
  
  int lockCheck;
  char t;
  
  read(sd, &lockCheck, sizeof(lockCheck));  // Taking lockCheck from the server
  if(lockCheck == 1)       //if lockCheck is 1 then already locaked
  {
    printf("Client is already logged in from another terminal\n");
    lockCheck = 0;
    return;
  }
  //no lock continue;
  
  read(sd, &user, sizeof(user));  //Taking the user structure from the server   
  
  while(1)
  {
  printf("\n\n\nPress the sr. no of the data you want to modify\n\n");
  printf("1.Change ID\n2. Primary User's 1st name\n3. Primary User's last name\n4. Account Balance\n");
  
  if(strcmp(user.loginType, "Normal")){
    printf("5. Secondary User's 1st name\n6. Secondary User's last name\n");
  }
  
  printf("\nPress '0' to choose another account\n");
  
  scanf("%d", &n);
  
  write(sd, &n, sizeof(n));    //Sending the choice to the server
    
  if(strcmp(user.loginType, "Normal")){
    switch(n){
      case 1 :
        changeID(sd,str);
        break;
      case 2 :
        nameChange(sd,str,n);
        break;
      case 3 :
        nameChange(sd,str,n);
        break;
      case 4 :
        balanceChange(sd,str);
        break;
      case 5 :
        nameChange(sd,str,n);
        break;
      case 6 :
        nameChange(sd,str,n);
        break;
      case 0 :
        goto exit_loop;
      default :
        printf("Invalid Input\n");
    }
  }
  else{
    switch(n){
        case 1 :
          changeID(sd,str);
          break;
        case 2 :
          nameChange(sd,str,n);
          break;
        case 3 :
          nameChange(sd,str,n);
          break;
        case 4 :
          balanceChange(sd,str);
          break;
        case 0 :
          goto exit_loop;
        default :
          printf("Invalid Input\n");
    }
  }//else
  }
  exit_loop: ;
  //
  }//while
}


void adminMenu(int sd){

  int n;
  int lockCheck;
  char t;
  
  while(1){
    printf("\n\n========================\n\n");
    printf("Press the sr. no to access the given feature\n");
    printf("\n\n1. Add a user\n2. Delete a user\n3. Modify user details\n4. Search user details\n\n");
    printf("Press '0' to return to the main menu\n");
  
    scanf("%d", &n);
    write(sd, &n, sizeof(n));  //Sending the choice to the server
  
    switch(n){
  
      case 1:
         printf("To add a new customer press any key\n\n");
  	getchar();
  	create(sd);
         break;
      
      case 2:
         int ul;
  	char str1[1000];
  
  	printf("Enter the user id of the account you want to delete : ");
  	scanf(" %[^\n]%*c", str1);
  	
  	write(sd, &str1, sizeof(str1));
  	
  	read(sd, &lockCheck, sizeof(lockCheck));  //Taking the lockCheck from the server
  					      // To check if locked or not
  	if(lockCheck == 1)       //if lockCheck is 1 then already locaked
          {
            printf("Client is already logged in from another terminal\n");
            lockCheck = 0;
            return;
          }
          else{    //no lock
          
            printf("Press any key to delete the user\n");
            scanf("%c", &t);
            write(sd, &t, sizeof(t));      //Send t to the server
            
            read(sd, &ul, sizeof(ul));     // Take ul from the server
  	
  	   if(ul == 0)
    	     printf("The file has been deleted\n");
  	   else
    	     printf("Unsuccessful Delete\n");
    	  
            break;
          
          }
      
      case 3:
        printf("Modify\n");
        modify(sd);   //Calling modify fn
        break;
      
      case 4:
         
         customer user;
         char str2[1000];
  	printf("Enter the user id of the account you want the details of : ");
  	scanf(" %[^\n]%*c", str2);
  	
  	write(sd, &str2, sizeof(str2));   //Send ID to the server
  	
  	int check;
  	read(sd, &check, sizeof(check));   //Take check from the user to check if user exists or not
  	if(check == -1){
    	  printf("The file does not exist\n");
    	  break;
   	}
   	
   	read(sd, &lockCheck, sizeof(lockCheck));  //LockCheck from server to check if locked or not
  	if(lockCheck == 1)       //if lockCheck is 1 then already locaked
          {
            printf("Client is already logged in from another terminal\n");
            lockCheck = 0;
            return;
          }
          else{    //no lock
   	
  	read(sd, &user, sizeof(user));   //Take user structure from the server
  	
  	//Printing the data of user structure taken from the server
  
  	printf("UserId is : %s \n", user.id);
  
  	printf("The password is : %s \n", user.password);
  
  	printf("The account balance is : %d \n", user.amount);
    
  	if(strcmp(user.loginType, "Normal")){
    	  printf("The secondary user's Full Name is : %s %s \n", user.fname2, user.lname2);
  	}
  
  	printf("The primary user's Full Name is : %s %s \n", user.fname1, user.lname1);
  	
  	printf("Press any key to go back\n");
         scanf("%c", &t);
         write(sd, &t, sizeof(t));  //Send t to the server
  	
         break;
        }
      
      case 0:
        return;
      
      default:
        printf("Input Invalid\n");
  
    }
  
  }

}

void adminLogin(int sd){
  
  bool resultid, resultpass;

  char givenID[100];
  char givenPass[100];
  int n;
  int size;
  
  while(1){
  
    printf("\n\n\n=========================\n\n");
    
    printf("Press '0' to go to Main menu or any number to continue\n");
    scanf("%d",&n);
    
    write(sd, &n, sizeof(n));   //Send choice to the server
    
    if(n == 0)
      break;
      
      
    printf("\n\nEnter the login id : ");
    scanf(" %[^\n]%*c", givenID);
    printf("%s \n", givenID); 
    size = sizeof(givenID);
    write(sd, &size, sizeof(size));          //Send ID size to the client
    write(sd, &givenID, sizeof(givenID));   //Send ID to server
    read(sd, &resultid, sizeof(resultid));   //take result from server
                                 //Result for id verification
    
    if(!resultid){
      printf("Incorrect id...\n");
      continue;
    }
      
    printf("Correct id...\n");
    
    while(1){
    
      printf("\nEnter the password : ");
      scanf(" %[^\n]%*c", givenPass);
      write(sd, &givenPass, sizeof(givenPass));   //send password to server
      read(sd, &resultpass, sizeof(resultpass));   //take result from server
    					     //Result for password verification
      if(!resultpass){
        printf("Access Denied... Incorrect Password\n");
        continue;
      }
      else
      {
       printf("Access Gained\n");
       adminMenu(sd);
       break;
      }
    }
  }
}

void mainMenu(int sd){
    int n;
    while(1){
      printf("\n\n\n======================================\n"); 
      printf("Select the type of user\n\n");
      printf("1. Customer\n2. Admin\n");
      printf("\nPress '0' to exit\n");
      printf("\nEnter the sr. no to select the type of user : ");  // Taking the choice from the user
      scanf("%d", &n);
      write(sd, &n, sizeof(n));  //Sending the choice to the server
      printf("\n");
    
      switch(n){
        case 1 :
          userMenu(sd);   //calling userMenu
          break;
        case 2 :
          adminLogin(sd);  //Calling Admin
          break;
        case 0 :
          printf("Good bye and Thank you for using our services\n"); //Exiting the system
          return;
        default :
          printf("Invalid Input... Retry\n");
      }
   }
}    

void main()
{
    int socketFd; // File descriptor that will be used for communication via socket
    int connectStatus;        // Determines success of `connect` call

    struct sockaddr_in address; // Holds the address of the server to communicate

    ssize_t readData, writeData; // Number of bytes read from / written to the network via socket
    char dataFromServer[100];

    socketFd = socket(AF_INET, SOCK_STREAM, 0); //Socket Creation
    if (socketFd == -1)
    {
        perror("Error : ");
        _exit(0);
    }
    printf("Client socket created!\n");

    // Defined server's details
    address.sin_addr.s_addr = htonl(INADDR_ANY);
    address.sin_family = AF_INET; 
    address.sin_port = htons(6000);// the htons() function converts values between host and network byte orders. These routines convert 16 and 32 bit quantities between network byte order and host byte order. (Network byte order is big endian, or most significant byte first.)

    connectStatus = connect(socketFd, (struct sockaddr *)&address, sizeof(address));
    if (connectStatus == -1)
    {
        perror("Error : ");
        _exit(0);
    }
    printf("Client to server connection established!\n");

// ========================= Client - Server communication =================

    mainMenu(socketFd);
    close(socketFd);
}
