#include <sys/ipc.h>    // For ipc i,e semaphores
#include <sys/sem.h>    // For semaphores
#include <sys/types.h>  // Import for `socket`, `bind`, `listen`, `accept`
#include <sys/socket.h> // Import for `socket`, `bind`, `listen`, `accept`
#include <netinet/ip.h> // Import for `struct sockaddr_in`, `htons`
#include <stdio.h>      // Import standard input/output functions
#include <unistd.h>     
#include <stdbool.h>    //for boolean variables
#include <stdlib.h>     //import standard functions
#include <string.h>     //import string functions
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>

typedef struct customer{   //User structure
    char id[100];
    char lname1[100];
    char lname2[100];
    char fname1[100];
    char fname2[100];
    char password[100];
    char loginType[10];
    int amount;
}customer;

typedef struct admin{     //Admin structure
    char id[100];
    char password[100];
    char fname[100];
    char lname[100];
}admin;

void menu(int sd, char id[100]){

  int n;
  customer user;
  int fd;
  
  struct flock lock,savelock;  
  int lockCheck;
  
  
  while(1){
 
    read(sd, &n, sizeof(n));  //taking choice from the client
     
    switch(n){
    
      case 1 :  //Deposite
         
         fd = open(id, O_RDWR);    //opening the file with the given id
  
         read(fd, &user, sizeof(user));   //Reading the structure from the file
     
         write(sd, &user, sizeof(user));  //Sending it to the client
         
         if(strcmp(user.loginType, "Joint") == 0){  //If user is joint then we perform record locking on the amount 
    
    	  lock.l_type = F_WRLCK;    //Write lock
    	  lock.l_whence = SEEK_SET; 
    	  lock.l_start = sizeof(user) - sizeof(user.amount);  //start the lock where the amount starts in user structure
    	  lock.l_len = sizeof(user.amount);  //lock length is the size of amount i.e int
    	  savelock = lock;
           lock.l_pid = getpid();
      
           fcntl(fd, F_GETLK, &lock);   //Checking if lock already exists or not for both rd/wr locks
           if (lock.l_type == F_WRLCK || lock.l_type == F_RDLCK)  //Lock exists
    	  {
      	    printf("Record is locked by another user.\n");
             lockCheck = 1;
             write(sd, &lockCheck, sizeof(lockCheck)); //send lock check to the client
             break;
           }
           else{  //no lock.. perform operation
             printf("no lock\n");
             lockCheck = 0;
             write(sd, &lockCheck, sizeof(lockCheck));  //send lock check to the client
             
             fcntl(fd, F_SETLK, &savelock);   //Setting the write lock
             
  	    read(sd, &user, sizeof(user));   //perform deposit at client and taking the structure from client
  	    lseek(fd,0,SEEK_SET);            // take the offset to the beginning of the file
  	    write(fd, &user, sizeof(user));  // write(replace) the structure to the file
  	    
  	    lock.l_type = F_UNLCK;          //unlock the amount record
  	    fcntl(fd, F_SETLK, &lock);      //unlocked
  	    printf("Unlocked\n");
             break;
           }
         }
         
         else{  //Normal user... mandatory lock already applied
           read(sd, &user, sizeof(user));  //perform deposit at client and taking the structure from client
           lseek(fd,0,SEEK_SET);           // take the offset to the beginning of the file
  	  write(fd, &user, sizeof(user)); // write(replace) the structure to the file
           break;
         
         }
        
      case 2 :  //withdraw
         
         fd = open(id, O_RDWR);   //opening the file with the given id
  
         read(fd, &user, sizeof(user));  //Reading the structure from the file
    
         write(sd, &user, sizeof(user));  //Sending it to the client
         
         if(strcmp(user.loginType, "Joint") == 0){  //If user is joint then we perform record locking on the amount 
    
    	  lock.l_type = F_WRLCK;                 //Write lock
    	  lock.l_whence = SEEK_SET;
    	  lock.l_start = sizeof(user) - sizeof(user.amount);  //start the lock where the amount starts in user structure
    	  lock.l_len = sizeof(user.amount);    	 //lock length is the size of amount i.e int
    	  savelock = lock;
           lock.l_pid = getpid();
      
           fcntl(fd, F_GETLK, &lock);                //Checking if lock already exists or not for both rd/wr locks
           if (lock.l_type == F_WRLCK || lock.l_type == F_RDLCK)  //Lock exists
    	  {
      	    printf("Record is locked by another user.\n");
             lockCheck = 1;
             write(sd, &lockCheck, sizeof(lockCheck));  //send lock check to the client
             break;
           }
           else{   //no lock.. move forward
             printf("no lock\n");
             lockCheck = 0;
             write(sd, &lockCheck, sizeof(lockCheck));   //send lock check to the client
             
             fcntl(fd, F_SETLK, &savelock);    //Setting the write lock
             
  	    read(sd, &user, sizeof(user));    //perform withdraw at client and taking the structure from client
  	    lseek(fd,0,SEEK_SET);             // take the offset to the beginning of the file
  	    write(fd, &user, sizeof(user));   // write(replace) the structure to the file
  	    
  	    lock.l_type = F_UNLCK;           //unlock the amount record
  	    fcntl(fd, F_SETLK, &lock);       //unlocked
  	    printf("Unlocked\n");            
             break;
           }
         }
         
         else{   //Normal user... mandatory lock already applied
           read(sd, &user, sizeof(user));     //perform deposit at client and taking the structure from client
           lseek(fd,0,SEEK_SET);              // take the offset to the beginning of the file
  	  write(fd, &user, sizeof(user));   // write(replace) the structure to the file
           break;
         
         }
        
      case 3 : //password change... no lock
      
         fd = open(id, O_RDWR);      //opening the file with the given id
  
         read(fd, &user, sizeof(user));    //Reading the structure from the file
    
         write(sd, &user, sizeof(user));   //Sending it to the client
      
         int passCheck;
         read(sd, &passCheck, sizeof(passCheck));  //to Check the old password ... Take passcheck from client
         if(passCheck == 1){    //if passCheck=1 ...incorrect password...Go back
           break;
         }
         else{  //Correct old password
           read(sd, &user, sizeof(user));  //updated password in client and taking the structure from client
           lseek(fd,0,SEEK_SET);           // take the offset to the beginning of the file
           write(fd, &user, sizeof(user)); // write(replace) the structure to the file
           break;
         }
         
      case 4 :  //balance enquiry
      
         fd = open(id, O_RDWR);        //opening the file with the given id
  
         read(fd, &user, sizeof(user));  //Reading the structure from the file
    
         write(sd, &user, sizeof(user));  //Sending it to the client
      
         if(strcmp(user.loginType, "Joint") == 0){  //If user is joint then we perform record locking on the amount
    
    	  lock.l_type = F_RDLCK;     //Read lock
    	  lock.l_whence = SEEK_SET;
    	  lock.l_start = sizeof(user) - sizeof(user.amount);//start the lock where the amount starts in user structure  	 
    	  lock.l_len = sizeof(user.amount);              //lock length is the size of amount i.e int
    	  savelock = lock;
           lock.l_pid = getpid();
      
           fcntl(fd, F_GETLK, &lock);    //Checking if lock already exists or not for write locks
           if (lock.l_type == F_WRLCK)   //lock exists
    	  {
      	    printf("Record is locked by another user.\n");
             lockCheck = 1;
             write(sd, &lockCheck, sizeof(lockCheck));  //send lock check to the client
             break;
           }
           else{ //no lock move forward
             int t;
             printf("no lock\n");
             lockCheck = 0;
             write(sd, &lockCheck, sizeof(lockCheck));  //send lock check to the client
             
             fcntl(fd, F_SETLK, &savelock);            //Set read lock
             
             read(sd, &t, sizeof(t));                  //Variable to unlock taken from the client
  	    
  	    lock.l_type = F_UNLCK;                   //unlock the amount record
  	    fcntl(fd, F_SETLK, &lock);               //unlocked
  	    printf("Unlocked\n");
             break;
           }
         }
         
         else{  //Normal user... mandatory lock already applied
           break;  //Reading the structure at the client side
         }
     
      case 5 :  //view details
      
         fd = open(id, O_RDWR);        //opening the file with the given id
  
         read(fd, &user, sizeof(user)); //Reading the structure from the file
    
         write(sd, &user, sizeof(user));  //Sending it to the client
      
         if(strcmp(user.loginType, "Joint") == 0){   //If user is joint then we perform record locking
    
    	  lock.l_type = F_RDLCK;        //Read lock
    	  lock.l_whence = SEEK_SET;
    	  lock.l_start = 0;            //Lock from the start
    	  lock.l_len = sizeof(user) - sizeof(user.amount); //Lock everything except account
    	  savelock = lock;
           lock.l_pid = getpid();
      
           fcntl(fd, F_GETLK, &lock);  //Checking if lock already exists or not for write locks
           if (lock.l_type == F_WRLCK) //lock exists
    	  {
      	    printf("Record is locked by another user.\n");
             lockCheck = 1;
             write(sd, &lockCheck, sizeof(lockCheck));  //send lock check to the client
             break;
           }
           else{  //no lock move forward
             int t;
             printf("no lock\n");
             lockCheck = 0;
             write(sd, &lockCheck, sizeof(lockCheck));  //send lock check to the client
             
             fcntl(fd, F_SETLK, &savelock);            //Set read lock
             
             read(sd, &t, sizeof(t));                   //Variable to unlock taken from the client
  	    
  	    lock.l_type = F_UNLCK;                   //unlock the records
  	    fcntl(fd, F_SETLK, &lock);               //unlocked
  	    printf("Unlocked\n");
             break;
           }
         }
         
         else{     //Normal user... mandatory lock already applied
           break;  //Reading the structure at the client side
         }
        
      default :
        printf("Returning to the previous menu....\n\n\n");
        return;
    }
    printf("\n\n\n");
  }
  close(fd);
}

void create(int sd){

  int n, check, fd;
  char userID[100];
  customer user;
  read(sd, &n, sizeof(n));  //Taking choice from the client
  
  if(n == 1)
    strcpy(user.loginType, "Normal");  // Normal user
  else if(n == 2)
    strcpy(user.loginType, "Joint");   // joint user
  else{
    printf("Input invalid\n");    // if invalid go back
    return;
  }
    
  while(1){
    
    read(sd, &userID, sizeof(userID));   //Take userID from the client
    fd = open(userID, O_RDWR | O_EXCL | O_CREAT, S_IRWXU);  //Creating a new file for the user (UserId is name of the file)
    //if file already exists then user id already exists given another userID
    // This is verified using the EXCL Flag
    
    if(fd == -1){
      check = 0;   
      write(sd, &check, sizeof(check)); // send check=0 to the client (already exist)
      continue;
    }
    else{
      check = 1;
      write(sd, &check, sizeof(check)); // send check=1 to the client (new userID created)
      break;
    }
  }
  
  read(sd, &user, sizeof(user));   //Taking the user structure from the client
  
  write(fd, &user, sizeof(user));  //Writing the user structure to the file created

  close(fd);
  
  return;

}

bool userIDCheck(int sd, char givenID[]){

  bool result;
  printf(" %s\n", givenID);
  int fd = open(givenID, O_RDONLY);   //Opening the user's file
  if(fd == -1){                       // if file does not exist result = false
    result = false;
  }
  else
    result = true;                //If file exists then result = true
  
  close(fd);
  write(sd, &result, sizeof(result));   //Send the result to the client
  return result;
  
}

bool userPassCheck(int sd, char givenID[], char givenPass[]){

  bool result;
  int fd = open(givenID, O_RDONLY);    //Opening the users's file.... It exists as we have already verified the ID
  customer user;
  
  read(fd, &user, sizeof(user));   //Reading the user's structure from the file
  close(fd);
  
  if(strcmp(user.password, givenPass)){   //Comparing the givenPassword and password from the structure 
    result = false;
  }
  else
  {
    result = true;
  }
  
  write(sd, &result, sizeof(result));  //Send the result to the client
  return result;
  
}

void userLogin(int sd){

  printf("Gone to userLogin\n");

  char givenID[100];
  char givenPass[100];
  bool resultid, resultpass;
  int size;
  int n;
  
  while(1){
    read(sd, &n, sizeof(n));  //Taking the choice from clinet to return to the main menu
    if(n == 0)
      break;
    read(sd, &size, sizeof(size)); //Taking the size of the givenID from the client
    read(sd, &givenID, size);      //Taking the ID from the client
    printf("%s \n", givenID); 
    resultid = userIDCheck(sd, givenID);  //Calling the userIDCheck function to check if the user if present or not.
    if(resultid == false)  //If true then take the password or start the while loop again
      continue;
    
    while(1){
      read(sd, &givenPass, sizeof(givenPass));     //Taking the password from the user
      resultpass = userPassCheck(sd, givenID ,givenPass);  //Calling the userPassCheck function to check if the password is correct or not.
      
      if(resultpass == false){   //Password incorrect
        if(strcmp(givenPass, "0") == 0){  //Type 0 to go back
          break;
        }
        continue;
      }
      else{     //Password correct move forward
        int lockCheck;      //Variable to check if locked or not and send it to the client
        customer user;
        int fd = open(givenID, O_RDWR);
        struct flock lock,savelock;  //initialising flock structure
  
        read(fd, &user, sizeof(user));  //read the structure of the given userid 
    
        write(sd, &user, sizeof(user)); //Send the structure to the client
    
        if(strcmp(user.loginType, "Normal") == 0){ //If the user is a normal user then apply MANDATORY locking
    
          lock.l_type = F_WRLCK;       //Write lock
          lock.l_whence = SEEK_SET;    //Offset set to the offset bytes
          lock.l_start = 0;            //Lock 
          lock.l_len = 0;              //whole structure locked
          savelock = lock;             
          lock.l_pid = getpid(); 
      
          fcntl(fd, F_GETLK, &lock);    //Get the lock if already locked
          if (lock.l_type == F_WRLCK || lock.l_type == F_RDLCK)  //If rd/wr lock exists then cant go forward
          {
            printf("File is write-locked by process.\n");
            lockCheck = 1;                             //set the lock check
            write(sd, &lockCheck, sizeof(lockCheck)); //Send it to the client
            return;
          }
          else{   //no lock move forward
            printf("No lock\n");
            lockCheck = 0;   //set lockCheck
            write(sd, &lockCheck, sizeof(lockCheck)); //Send it to client
            fcntl(fd, F_SETLK, &savelock);           //Applying the actual lock
            menu(sd, givenID);                      //Calling the menu function after locking
            lock.l_type = F_UNLCK;                  //lock type to unlock after returing from menu
  	   fcntl(fd, F_SETLK, &lock);             //UNlocking the file.
            printf("Unlocked\n");
          }
        }
        
        else{ //joint user
          
          // Critical Section...
          menu(sd, givenID);
         
        }//else of joint user
        
        break;
      }
    }
  }
  return;

}

void userMenu(int sd){
  int n;
  while(1){
  read(sd, &n, sizeof(n));  //Taking the choice from the client
  if(n == 1){
    printf("Gone to userLogin\n");
    userLogin(sd);     //Calling userLogin
    continue;
  }
  else if(n == 2){
    printf("Gone to create\n");
    create(sd);          //Calling customer create
    continue;
  }
  else
    return;
  }
}

bool adminIDCheck(int sd, char givenID[]){

  bool result;
  printf(" %s\n", givenID);
  int fd = open(givenID, O_RDONLY);  //Opening the admin's file
  if(fd == -1){                      // if file does not exist result = false
    result = false;
  }
  else
    result = true;                  //If file exists then result = true
  
  close(fd);
  write(sd, &result, sizeof(result));   //Send the result to the client
  return result;
  
}

bool adminPassCheck(int sd, char givenID[], char givenPass[]){

  bool result;
  int fd = open(givenID, O_RDONLY);   //Opening the admin's file.... It exists as we have already verified the ID
  admin boss;
  
  read(fd, &boss, sizeof(boss));      //Reading the admin's structure from the file
  close(fd);
  
  if(strcmp(boss.password, givenPass)){   //Comparing the givenPassword and password from the structure 
    result = false;
  }
  else
  {
    result = true;
  }
  
  write(sd, &result, sizeof(result));   //Send the result to the client
  return result;
  
}

void nameChange(int sd, char str[100], int n){
  
  customer user;
  char name[100];
  int fd = open(str, O_RDWR);    //Open the file with given id
  
  read(fd, &user, sizeof(user));  //read the structure from the file
  write(sd, &user, sizeof(user)); //Sending the user structure to the client
  
  read(sd, &name, sizeof(name));  // Taking the name from user
  
  //Updating the names accordingly in structure
  if(n == 2)
    strcpy(user.fname1, name);   
  if(n == 3)
    strcpy(user.lname1, name);
  if(n == 5)
    strcpy(user.fname2, name);
  if(n == 6)
    strcpy(user.lname2, name);
    
  lseek(fd,0,SEEK_SET);       //Setting the offset to start
  write(fd, &user, sizeof(user));  //Updating the file with userID
  
  return;

}

void balanceChange(int sd, char str[100]){

  int newAmount;
  customer user;

  int fd = open(str, O_RDWR);    //Open the file with given id
  read(fd, &user, sizeof(user)); //read the structure from the file
  
  write(sd, &user, sizeof(user));  //Sending the user structure to the client
  
  read(sd, &user, sizeof(user));  //Taking the updated structure from the client
  
  lseek(fd,0,SEEK_SET);           //Setting the offset to start
  write(fd, &user, sizeof(user)); //Updating the file with userID

  return;
}

void changeID(int sd, char str[100]){
  
  char newID[100];
  customer user;
  int fd = open(str, O_RDWR);    //Open the file with given id
  
  read(fd, &user, sizeof(user));  //read the structure from the file
  
  write(sd, &user, sizeof(user));  //Sending the user structure to the client
  
  read(sd, &newID, sizeof(newID)); //Taking the newID from the client
  
  strcpy(user.id, newID);        //updating the structure with the new ID
  lseek(fd,0,SEEK_SET);          //Setting the offset to start
  write(fd, &user, sizeof(user)); //Updating the file with userID
  
  int l = link(str, newID);       //Creating a hard link of the file
  write(sd, &l, sizeof(l));       //Sending l for verification
  if(l == 0)
    printf("New file created\n");
  else{
    printf("Unsuccessful\n");
    return;
  }
    
  int ul = unlink(str);         //Unlinking the original file
  write(sd, &ul, sizeof(ul));   //Sending ul for verification
  if(l == 0)
    printf("Old file deleted\n");
  else{
    printf("Unsuccessful delete\n");
    return; 
  }
    
  return;

}

void modify(int sd){
  int n;
  char str[1000];
  customer user;
  int fd;
  while(1){
  
  while(1){
    
    read(sd, &str, sizeof(str));   //Taking the ID from the client
    if(strcmp(str, "0") == 0)
      return;
  
    fd = open(str, O_RDWR);       //Open the file with given id
    write(sd, &fd, sizeof(fd));   //Send fd to the client
    if(fd == -1){
      continue;
    }
    else
      break;
  }
  
  struct flock lock,savelock;
  int lockCheck;
  char t;
  	
  lock.l_type = F_WRLCK;       //Write lock
  lock.l_whence = SEEK_SET;    //Offset set to the offset bytes
  lock.l_start = 0;            //Lock 
  lock.l_len = 0;              //whole structure locked
  savelock = lock;             
  lock.l_pid = getpid();
         
  fcntl(fd, F_GETLK, &lock);    //Get the lock if already locked
  if (lock.l_type == F_WRLCK || lock.l_type == F_RDLCK)  //If rd/wr lock exists then cant go forward
  {
    printf("File is write-locked by process.\n");
    lockCheck = 1;                             //set the lock check
    write(sd, &lockCheck, sizeof(lockCheck)); //Send it to the client
    return;
  }
  
  lockCheck = 0;                             //set the lock check
  write(sd, &lockCheck, sizeof(lockCheck));  //Send it to the client
  fcntl(fd, F_SETLK, &savelock);             // Applying the actual lock
  
  read(fd, &user, sizeof(user));      //Read structure from the file
  write(sd, &user, sizeof(user));     //Send user structue to the client
  
  while(1)
  {
  
  read(sd, &n, sizeof(n));        //Take the choice from the client
  
  if(strcmp(user.loginType, "Normal")){  //If joint
    switch(n){
      case 1 :
        changeID(sd,str);
        break;
      case 2 :
        nameChange(sd,str,n);
        break;
      case 3 :
        nameChange(sd,str,n);
        break;
      case 4 :
        balanceChange(sd,str);
        break;
      case 5 :
        nameChange(sd,str,n);
        break;
      case 6 :
        nameChange(sd,str,n);
        break;
      case 0 :
        goto exit_loop;
      default :
        printf("Invalid Input\n");
    }
  }
  else{    //If normal
    switch(n){
        case 1 :
          changeID(sd,str);
          break;
        case 2 :
          nameChange(sd,str,n);
          break;
        case 3 :
          nameChange(sd,str,n);
          break;
        case 4 :
          balanceChange(sd,str);
          break;
        case 0 :
          goto exit_loop;
        default :
          printf("Invalid Input\n");
    }
  }//else
  }
  exit_loop: ;
  
  lock.l_type = F_UNLCK;                  //lock type to unlock after returing from menu
  fcntl(fd, F_SETLK, &lock);             //UNlocking the file.
  printf("Unlocked\n");
  
  }//while
}

void adminMenu(int sd){

  int n,fd;
  struct flock lock,savelock;
  int lockCheck;
  char t;
  while(1){
    
    read(sd, &n, sizeof(n));    //Taking the choice from the client
  
    switch(n){
  
      case 1:
  	create(sd);
         break;
      
      case 2:
         int ul;
  	char str1[1000];
  	
  	read(sd, &str1, sizeof(str1));   //Taking the ID from the client
  	fd = open(str1, O_RDWR);
  	
  	lock.l_type = F_WRLCK;       //Write lock
         lock.l_whence = SEEK_SET;    //Offset set to the offset bytes
         lock.l_start = 0;            //Lock 
         lock.l_len = 0;              //whole structure locked
         savelock = lock;             
         lock.l_pid = getpid();
         
         fcntl(fd, F_GETLK, &lock);    //Get the lock if already locked
          if (lock.l_type == F_WRLCK || lock.l_type == F_RDLCK)  //If rd/wr lock exists then cant go forward
          {
            printf("File is write-locked by process.\n");
            lockCheck = 1;                             //set the lock check
            write(sd, &lockCheck, sizeof(lockCheck)); //Send it to the client
            return;
          }
          else{   //no lock move forward
            
            lockCheck = 0;                             //set the lock check
            write(sd, &lockCheck, sizeof(lockCheck));  //Send it to the client
            fcntl(fd, F_SETLK, &savelock);             // Applying the actual lock
            
            read(sd, &t, sizeof(t));                   //wait to exit
            
            ul = unlink(str1);                       //Unlink the file
  	   write(sd, &ul, sizeof(ul));             //Send ul to the client
  	   
  	   lock.l_type = F_UNLCK;                  //lock type to unlock after returing from menu
  	   fcntl(fd, F_SETLK, &lock);             //UNlocking the file.
            printf("Unlocked\n");
            break;
          
          }
         
      case 3:
        printf("Modify\n");
        modify(sd);   //Calling modify function
        break;
      
      case 4:
         customer user;
         char str2[1000];  
  	
  	read(sd, &str2, sizeof(str2));  //Taking the ID from the client
  	fd = open(str2, O_RDWR);        //Opening the file with the given ID
  	write(sd, &fd, sizeof(fd));    //Send fd to the client
  	if(fd == -1){
    	  break;
   	}
  	
  	lock.l_type = F_RDLCK;       //Write lock
         lock.l_whence = SEEK_SET;    //Offset set to the offset bytes
         lock.l_start = 0;            //Lock 
         lock.l_len = 0;              //whole structure locked
         savelock = lock;             
         lock.l_pid = getpid();
         
         fcntl(fd, F_GETLK, &lock);    //Get the lock if already locked
          if (lock.l_type == F_WRLCK)  //If wr lock exists then cant go forward
          {
            printf("File is write-locked by process.\n");
            lockCheck = 1;                             //set the lock check
            write(sd, &lockCheck, sizeof(lockCheck)); //Send it to the client
            return;
          }
          else{   //no lock move forward
            
            lockCheck = 0;                             //set the lock check
            write(sd, &lockCheck, sizeof(lockCheck));  //Send it to the client
            fcntl(fd, F_SETLK, &savelock);             // Applying the actual lock
            
         ////////
   	
  	   read(fd, &user, sizeof(user));        //Read the structure from the file
  
   	   write(sd, &user, sizeof(user));      //Send the structure to the client
  	
  	   read(sd, &t, sizeof(t));                   //wait to exit
  	///////
  	
  	   close(fd);
  	
  	   lock.l_type = F_UNLCK;                  //lock type to unlock after returing from menu
  	   fcntl(fd, F_SETLK, &lock);             //UNlocking the file.
            printf("Unlocked\n");
  	
            break;
          }
 
      
      case 0:
        return;
      
      default:
        printf("Input Invalid\n");
  
    }
  
  }

}

void adminLogin(int sd){

  printf("Gone to adminLogin\n");

  char givenID[100];
  char givenPass[100];
  bool resultid, resultpass;
  int size;
  int n;
  char temp[100];
  
  while(1){
    read(sd, &n, sizeof(n));       //Taking the choice to go back or not
    if(n == 0)
      break;
    read(sd, &size, sizeof(size));   //Taking the size of the givenID
    read(sd, &givenID, size);        //Taking the givenID
    printf("%s \n", givenID);
    
    resultid = adminIDCheck(sd, givenID);   //Calling the adminIDCheck fn
    if(resultid == false)                  //If result is false loop again
      continue;
    
    while(1){
      read(sd, &givenPass, sizeof(givenPass));  //Taking the password
      resultpass = adminPassCheck(sd, givenID ,givenPass);  //Calling the adminIDCheck fn
      if(resultpass == false)  //If result is false loop again
        continue;
      else    //if true then continue your business
        printf("adminMenu\n");  
        adminMenu(sd);
        break;
    }
  }
  return;

}

void mainMenu(int sd){
  int n;
  while(1){
      read(sd, &n, sizeof(n)); // Taking the choice from the client
      if(n == 1){
        printf("Gone to userMenu\n");
        userMenu(sd);         //Calling userMenu
        continue;
      }
      else if(n == 2){
        adminLogin(sd);      //Calling Admin Menu
        continue;
      }
      else if(n == 0){       // To exit the whole system ...(current client only)  
        return;
      }
      else
        continue;            //Invalid Input
    }
}


int main(){
  struct sockaddr_in server,client; 
  int sd,nsd,clientLen;
  bool result;
  sd=socket(AF_INET,SOCK_STREAM,0);   // int socket (int family, int type, int protocol);  // returns socket descriptor
  server.sin_family=AF_INET;          
  server.sin_addr.s_addr=INADDR_ANY;  
  server.sin_port=htons(6000);
  
  	
  bind(sd,(struct sockaddr *)&server,sizeof(server));  // bind returns 0 on success and -1 on failure
	// The bind function assigns a local protocol address to a socket.
  listen(sd,5);	// listen function converts an unconnected socket into a passive socket
                  //10 clients per connection// listen returns 0 on success and -1 on error.
                 
  ///////////////////////////////////
         
  write(1,"Waiting for the client.....\n",sizeof("Waiting for the client.....\n"));
  while(1){
  
  ////////////////////
  
    clientLen = sizeof(client);
    nsd=accept(sd,(struct sockaddr *)&client,&clientLen);

    write(1,"Connected to the client.....\n",sizeof("Connected to the client...\n"));
    if(!fork()){
      close(sd);	//close the old socket desc. as the new socket desc is created by accept()
      mainMenu(nsd);
      printf("Exit\n");
      exit(0);
    }
    else{
      close(nsd);	// nsd is implemented in child only.
    }
  }
  return 0;
}
